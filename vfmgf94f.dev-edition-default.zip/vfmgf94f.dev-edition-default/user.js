user_pref("dom.ipc.plugins.enabled", false);
user_pref("plugin.state.npcaosoft_web_print_lodop", 2);
